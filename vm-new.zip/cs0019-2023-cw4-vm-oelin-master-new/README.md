This is UCL CS 0019 Coursework 4.

The CW4 handout is available at:

http://www.cs.ucl.ac.uk/staff/B.Karp/0019/s2023/cw/cw4-vm.pdf
