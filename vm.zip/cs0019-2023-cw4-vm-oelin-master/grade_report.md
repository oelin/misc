## COMP0019 CW4 Grade Report
Graded at: 2023-03-02 10:46:42.638395

Report for commit SHA: d08dd563392323a19733b74373a67aa8a428a456

### Output


    Kernel isolation failed at tick 0
    Process isolation failed at tick 0
    Virtual page allocation failed at tick 500
    Overlapping address spaces failed at tick 800
    Fork failed at tick 0
    Total score: 0/5
    


### Marking

Total score: 0 / 100

